# CatKid Mobile 1.4

Aplicativo Android independente com configurações locais e painel flutuante.

## Usar o painel
1. Instale e abra o aplicativo.
2. Toque em **ABRIR PAINEL FLUTUANTE**.
3. Autorize **Sobrepor a outros apps** nas configurações do Android.
4. Volte ao CatKid e toque novamente no botão.
5. Arraste o painel pelo título.
6. Use **MINIMIZAR/EXPANDIR** para recolher ou mostrar controles; **FECHAR** encerra o painel.

Os controles disponíveis modificam preferências locais e aparência do próprio CatKid. Este projeto não acessa a memória de outros processos, não injeta código em jogos, não rastreia jogadores nem automatiza ações dentro de outros aplicativos.

O EXE original é um binário Windows; sem seu código-fonte e sem especificações verificáveis, não é possível prometer uma conversão integral. Recursos que dependem de integração interna com jogos precisam de uma implementação Android separada e podem não ter equivalente compatível.

## Compilar
Use o workflow GitHub Actions incluído ou compile `:app:assembleDebug` com Java 17 e Android SDK 35.
