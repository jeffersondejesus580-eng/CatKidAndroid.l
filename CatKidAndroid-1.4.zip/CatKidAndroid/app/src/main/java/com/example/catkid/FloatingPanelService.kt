package com.example.catkid

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createPanel()
    }

    private fun createPanel() {
        val prefs = getSharedPreferences("catkid_settings", MODE_PRIVATE)
        val bg = 0xFF111923.toInt()
        val accent = when (prefs.getString("accent", "Verde")) {
            "Azul" -> 0xFF65A9FF.toInt()
            "Roxo" -> 0xFFB69CFF.toInt()
            else -> 0xFF57D6BE.toInt()
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "CATKID  •  PAINEL"
            setTextColor(accent)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 12)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Painel flutuante independente"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, 0, 0, 12)
        }
        root.addView(subtitle)

        fun addToggle(label: String, key: String, default: Boolean) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 8, 0, 8)
            }
            val text = TextView(this).apply {
                this.text = label
                setTextColor(Color.WHITE)
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val button = Button(this).apply {
                text = if (prefs.getBoolean(key, default)) "LIGADO" else "DESLIGADO"
                setOnClickListener {
                    val next = !prefs.getBoolean(key, default)
                    prefs.edit().putBoolean(key, next).apply()
                    text = if (next) "LIGADO" else "DESLIGADO"
                }
            }
            row.addView(text)
            row.addView(button)
            root.addView(row)
        }
        addToggle("Indicador visual", "overlay_indicator", true)
        addToggle("Modo compacto", "compact_ui", false)
        addToggle("Animações do painel", "animations", true)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val minimize = Button(this).apply {
            text = "MINIMIZAR"
            setOnClickListener {
                val content = root.getChildAt(1)
                val compact = root.tag as? Boolean ?: false
                for (i in 1 until root.childCount - 1) {
                    root.getChildAt(i).visibility = if (compact) View.VISIBLE else View.GONE
                }
                root.tag = !compact
                text = if (compact) "MINIMIZAR" else "EXPANDIR"
            }
        }
        val close = Button(this).apply {
            text = "FECHAR"
            setOnClickListener { stopSelf() }
        }
        actions.addView(minimize, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(close, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)

        // Drag by touching the title area.
        title.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(root, params)
                        return true
                    }
                }
                return true
            }
        })

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 120
        }
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
