# CatKid Mobile — projeto Android

Projeto Android independente em Kotlin + Jetpack Compose.

## Funções implementadas
- Perfis **Padrão**, **Desempenho**, **Visual** e **Personalizado** que aplicam configurações reais.
- Preferências salvas localmente no aparelho e restauradas ao reabrir o app.
- Interface compacta que altera espaçamentos e tamanho do cabeçalho.
- Opção de animação aplicada aos painéis.
- Indicador de status que pode ser ocultado.
- Sons de clique da interface (quando ativados e permitidos pelo aparelho).
- Cor de destaque Verde, Azul ou Roxo, atualizada imediatamente.
- Botão para restaurar as configurações padrão.

## Limites da adaptação
O arquivo `cat_kid.exe` é um executável Windows, não o código-fonte. A inspeção estática encontrou referências a conteúdo do Fortnite e bibliotecas/APIs gráficas do Windows. Strings isoladas não revelam toda a lógica nem provam a função de cada opção.

Este projeto Android implementa uma interface e preferências independentes. Não se conecta ao Fortnite ou a outros jogos, não lê nem modifica memória de outros apps e não reproduz mecanismos de interação com jogos do programa Windows. Portanto, não é uma conversão funcional 1:1 do EXE.

## Gerar APK
1. Extraia o ZIP.
2. Abra a pasta `CatKidAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
4. Selecione **Build > Build APK(s)**.
5. O APK de debug será criado em `app/build/outputs/apk/debug/`.

## Gerar APK sem computador (pelo GitHub no celular)
1. Crie um repositório no GitHub pelo navegador do celular.
2. Envie os arquivos desta pasta para o repositório, incluindo a pasta oculta `.github/workflows`.
3. Abra a aba **Actions** e execute **Build Android APK** (ou aguarde o build após enviar para `main`).
4. Quando terminar, abra a execução e baixe o artefato `CatKidMobile-debug`.
5. Dentro do artefato estará `app-debug.apk`.

**Importante:** o ambiente desta conversa não tem Android SDK/Gradle configurados. O código foi atualizado, mas o APK ainda não foi compilado nem testado aqui.
