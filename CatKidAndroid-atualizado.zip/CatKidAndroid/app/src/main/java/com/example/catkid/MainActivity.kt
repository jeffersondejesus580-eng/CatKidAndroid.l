package com.example.catkid

import android.os.Bundle
import android.view.SoundEffectConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0D1118)
private val Panel = Color(0xFF171F2B)
private val Muted = Color(0xFF9EACBA)
private fun accentFor(choice: String) = when (choice) {
    "Azul" -> Color(0xFF65A9FF)
    "Roxo" -> Color(0xFFB69CFF)
    else -> Color(0xFF57D6BE)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("catkid_settings", MODE_PRIVATE)
        setContent {
            var profile by remember { mutableStateOf(prefs.getString("profile", "Padrão") ?: "Padrão") }
            var compactUi by remember { mutableStateOf(prefs.getBoolean("compact_ui", false)) }
            var animations by remember { mutableStateOf(prefs.getBoolean("animations", true)) }
            var showStatus by remember { mutableStateOf(prefs.getBoolean("show_status", true)) }
            var sound by remember { mutableStateOf(prefs.getBoolean("sound", false)) }
            var accentChoice by remember { mutableStateOf(prefs.getString("accent", "Verde") ?: "Verde") }
            var expanded by remember { mutableStateOf(false) }
            var saved by remember { mutableStateOf(false) }
            val view = LocalView.current
            val accent = accentFor(accentChoice)
            val gap = if (compactUi) 8.dp else 14.dp
            val innerPad = if (compactUi) 12.dp else 16.dp

            fun persist() {
                prefs.edit().putString("profile", profile)
                    .putBoolean("compact_ui", compactUi)
                    .putBoolean("animations", animations)
                    .putBoolean("show_status", showStatus)
                    .putBoolean("sound", sound)
                    .putString("accent", accentChoice).apply()
                saved = true
            }
            fun applyProfile(name: String) {
                profile = name
                when (name) {
                    "Padrão" -> { compactUi = false; animations = true; showStatus = true; sound = false; accentChoice = "Verde" }
                    "Desempenho" -> { compactUi = true; animations = false; showStatus = true; sound = false; accentChoice = "Azul" }
                    "Visual" -> { compactUi = false; animations = true; showStatus = true; sound = true; accentChoice = "Roxo" }
                    // Personalizado keeps the current individual choices.
                }
                persist()
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = accent, secondary = accent, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(if (compactUi) 12.dp else 18.dp),
                        verticalArrangement = Arrangement.spacedBy(gap)
                    ) {
                        Text("CATKID", color = accent, fontSize = if (compactUi) 24.sp else 28.sp, fontWeight = FontWeight.Black)
                        Text("PAINEL ANDROID • CONFIGURAÇÕES LOCAIS", color = Muted, fontSize = 11.sp)

                        CardBlock("PERFIL", accent, animations, innerPad) {
                            Box {
                                OutlinedButton(onClick = { expanded = true }) { Text("Perfil: $profile") }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    listOf("Padrão", "Desempenho", "Visual", "Personalizado").forEach { item ->
                                        DropdownMenuItem(text = { Text(item) }, onClick = {
                                            applyProfile(item); expanded = false
                                        })
                                    }
                                }
                            }
                            Text("Os perfis aplicam combinações reais das opções abaixo.", color = Muted, fontSize = 12.sp)
                        }

                        CardBlock("INTERFACE", accent, animations, innerPad) {
                            SwitchLine("Interface compacta", compactUi) {
                                compactUi = it; profile = "Personalizado"; persist()
                                if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
                            }
                            SwitchLine("Animações da interface", animations) {
                                animations = it; profile = "Personalizado"; persist()
                                if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
                            }
                            SwitchLine("Exibir indicadores de status", showStatus) {
                                showStatus = it; profile = "Personalizado"; persist()
                                if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
                            }
                            SwitchLine("Sons da interface", sound) {
                                sound = it; profile = "Personalizado"; persist()
                                if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
                            }
                        }

                        CardBlock("APARÊNCIA", accent, animations, innerPad) {
                            Text("Cor de destaque", color = Muted, fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Verde", "Azul", "Roxo").forEach { c ->
                                    FilterChip(selected = accentChoice == c, onClick = {
                                        accentChoice = c; profile = "Personalizado"; persist()
                                        if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
                                    }, label = { Text(c) })
                                }
                            }
                            Text("A cor muda imediatamente e fica salva no aparelho.", color = Muted, fontSize = 11.sp)
                        }

                        CardBlock("AÇÕES", accent, animations, innerPad) {
                            OutlinedButton(onClick = { applyProfile("Padrão") }, modifier = Modifier.fillMaxWidth()) {
                                Text("Restaurar configurações padrão")
                            }
                        }

                        CardBlock("INFORMAÇÕES", accent, animations, innerPad) {
                            Text("Versão Android: 1.2", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("As opções controlam a interface e as preferências locais do CatKid Mobile. O app não se conecta a jogos, não lê memória de outros aplicativos e não altera outros apps.", color = Muted, fontSize = 12.sp)
                        }
                        if (showStatus) {
                            Text(if (saved) "✓ Configurações salvas neste aparelho." else "● Pronto • configurações locais", color = accent, fontSize = 12.sp)
                        }
                        Text("O arquivo enviado é um programa Windows. Sem o código-fonte, não é possível converter todas as funções originais para Android nem verificar seu comportamento completo.", color = Color(0xFFFFD18A), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CardBlock(title: String, accent: Color, animations: Boolean, contentPadding: androidx.compose.ui.unit.Dp, content: @Composable ColumnScope.() -> Unit) {
    val base = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(contentPadding)
    Column(
        (if (animations) base.animateContentSize() else base),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
